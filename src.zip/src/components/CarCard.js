import { Link } from 'react-router-dom';

function CarCard({ car }) {
  const { brand, price, year, image } = car;

  return (
    <div className="car-card">
      <div className="car-info">
        <h3>{brand}</h3>

        <p>💰 Price: ${price}</p>
        <p>📅 Year: {year}</p>
        {car.price > 30000 ? <p>Luxury</p> : <p>Standard</p>}
        </div>
        
        <img
          src={image}
          alt={brand}
          className="car-image"
        />
        <Link to={`/cars/${car.id}`} className="button-85">
            View Details
          </Link>

    </div>
  );
}

export default CarCard;
