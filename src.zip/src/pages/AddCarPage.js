import React, { useContext } from 'react';
import AddCarForm from "../components/AddCarForm";
import { AuthContext } from '../context/AuthContext';

export default function AddCarPage({ addCar }) {
  const { user } = useContext(AuthContext);

  const handleSave = async (formData) => {
    const response = await fetch('http://localhost:5000/cars', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...formData, owner: user.username }),
    });

    if (response.ok) {
      addCar(await response.json());
      alert("Success!");
    }
  };

  return <AddCarForm addCar={handleSave} />;
}