import HeroBanner from "../components/HeroBanner";
import Footer from "../components/Footer";
import { Link, Outlet} from "react-router-dom";




export default function Home() {
  return (
    <div>
      <HeroBanner />
      <nav className="homecss">
        <Link to="stats" className="nav-button">Stats</Link> 
        <Link to="details" className="nav-button">Details</Link>
      </nav>
      <Outlet />
      
      <Footer/>
    </div>
  );
}