import React, { useContext, useState } from 'react';
import { AuthContext } from '../context/AuthContext';

const MyCarsPage = ({ cars, deleteCar, updateCar }) => {
  const { user } = useContext(AuthContext);
  
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({});

  const myCars = cars.filter(car => car.owner === user.username);

  const startEdit = (car) => {
    setEditingId(car.id);
    setFormData(car);
  };

  const handleSave = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/cars/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const updated = await response.json();
        updateCar(updated);
        setEditingId(null);
      }
    } catch (err) {
      alert("Save error");
    }
  };

  return (
    <div>
      <h2>My cars</h2>
      <div>
        {myCars.length === 0 ? (
          <p>You haven't add post yet.</p>
        ) : (
          myCars.map(car => (
            <div key={car.id} className="car-card">
              {editingId === car.id ? (
                <div className="edit-form-container">
                  <div className="edit-form-inputs">
                    <input 
                      type="text" 
                      className="edit-input" 
                      placeholder="Brand"
                      value={formData.brand} 
                      onChange={(e) => setFormData({...formData, brand: e.target.value})} 
                    />
                    <input 
                      type="number" 
                      className="edit-input edit-input-price" 
                      placeholder="Price"
                      value={formData.price} 
                      onChange={(e) => setFormData({...formData, price: e.target.value})} 
                    />
                    <input 
                      type="number" 
                      className="edit-input edit-input-price" 
                      placeholder="Year"
                      value={formData.year} 
                      onChange={(e) => setFormData({...formData, year: e.target.value})} 
                    />
                  </div>
                  
                  <div className="edit-form-actions">
                    <button className="btn-save" onClick={() => handleSave(car.id)}>Save</button>
                    <button className="btn-cancel" onClick={() => setEditingId(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <div>

                <div className="car-info">
                  <h3>{car.brand}</h3>
                  <p>Cost: {car.price}$ </p>
                  <p>Year: {car.year}</p>
                </div>

                <img src={car.image} alt={car.brand} className="car-image" />

                  <button onClick={() => startEdit(car)} className="button-85" role="button">Edit</button>
                  <button onClick={() => deleteCar(car.id)} className="delete-btn">Delete</button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default MyCarsPage;

