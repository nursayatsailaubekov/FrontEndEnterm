import SearchBar from "../components/SearchBar";
import CarList from "../components/CarList";
import { useState, useMemo } from "react";

export default function SearchPage({ cars }) {
  const [search, setSearch] = useState("");

  const filteredCars = useMemo(() => {
    return cars.filter(car =>
      car.brand.toLowerCase().includes(search.toLowerCase())
    );
  }, [cars, search]); 

  return (
    <div>
      <SearchBar setSearch={setSearch} />
      <CarList cars={filteredCars} />
    </div>
  );
}